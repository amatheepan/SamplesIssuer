/**
 * 
 */
package org.tch.ste.auth.service.internal.token;

import org.tch.ste.domain.entity.PaymentInstrument;

/**
 * @author sharduls
 * 
 */
public class TokenLifeCycleHandlerImpl implements TokenLifeCycleHandler {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.tch.ste.auth.service.internal.token.TokenLifeCycleHandler#create(
	 * org.tch.ste.domain.entity.PaymentInstrument)
	 */
	@Override
	public void create(PaymentInstrument paymentInstrument) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.tch.ste.auth.service.internal.token.TokenLifeCycleHandler#deactivate
	 * (org.tch.ste.domain.entity.PaymentInstrument)
	 */
	@Override
	public void deactivate(PaymentInstrument paymentInstrument) {
		// TODO Auto-generated method stub

	}

}
