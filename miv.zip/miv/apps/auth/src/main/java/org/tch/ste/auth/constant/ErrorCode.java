/**
 * 
 */
package org.tch.ste.auth.constant;

/**
 * Error Codes.
 * 
 * @author Karthik.
 * 
 */
public enum ErrorCode {
    /**
     * Login Error.
     */
    LOGIN_ERROR;
}
