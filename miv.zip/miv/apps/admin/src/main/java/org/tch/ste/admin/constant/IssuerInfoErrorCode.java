package org.tch.ste.admin.constant;

/**
 * @author pamartheepan
 * 
 */
public enum IssuerInfoErrorCode {
    /**
     * 
     */
    IISN_ALREADY_EXISTS,
    /**
     * 
     */
    NAME_ALREADY_EXISTS;
}
