/**
 * 
 */
package org.tch.ste.admin.constant;

/**
 * @author anus
 * 
 */
public enum CustomerManagementErrorCode {
    /**
     * 
     */
    CUSTOMER_LOCK_STATUS,
    /**
     * 
     */
    CUSTOMER_UNLOCK_STATUS;

}
