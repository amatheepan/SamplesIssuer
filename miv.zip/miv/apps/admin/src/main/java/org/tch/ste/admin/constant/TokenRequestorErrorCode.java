/**
 * 
 */
package org.tch.ste.admin.constant;

/**
 * @author anus
 * 
 */
public enum TokenRequestorErrorCode {
    /**
     * 
     */
    NETWORK_ID_ALREADY_EXISTS,
    /**
     * 
     */
    TOKEN_REQUESTOR_NAME_ALREADY_EXISTS,
    /**
     * 
     */
    DELETE_TOKEN_REQUESTOR_MESSAGE,
    /**
     * 
     */
    REAL_BIN_SHOULD_NOT_IN_TOKEN_BIN,
    /**
     * 
     */
    SAVE_TOKEN_REQUESTOR_MESSAGE;
}
