/**
 * 
 */
package org.tch.ste.admin.service.core.issuer;

import java.util.Comparator;

/**
 * The comparator which is used to do custom sorting.
 * 
 * @author ramug
 * 
 */
public interface AuthenticationComparator extends Comparator<Object> {

    // empty.

}
