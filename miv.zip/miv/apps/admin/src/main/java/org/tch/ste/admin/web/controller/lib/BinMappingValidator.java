/**
 * 
 */
package org.tch.ste.admin.web.controller.lib;

import org.springframework.validation.Validator;

/**
 * @author pamartheepan
 * 
 */
public interface BinMappingValidator extends Validator {
    // Empty.
}
