/**
 * 
 */
package org.tch.ste.vault.service.internal.batch;

import java.io.Serializable;

/**
 * An abstract class which needs to be implemented by the specific batch
 * process.
 * 
 * @author Karthik.
 * 
 */
public abstract class BatchTaskletParameter implements Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -7853575669122177717L;

}
